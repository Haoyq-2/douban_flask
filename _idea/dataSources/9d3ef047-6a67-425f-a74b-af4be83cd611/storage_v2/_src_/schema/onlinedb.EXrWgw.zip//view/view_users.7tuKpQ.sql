create view view_users as
select `onlinedb`.`users`.`uNAME` AS `uName`, `onlinedb`.`users`.`uPhone` AS `uPhone`
from `onlinedb`.`users`;

-- comment on column view_users.姓名 not supported: 姓名

-- comment on column view_users.电话 not supported: 电话号码

